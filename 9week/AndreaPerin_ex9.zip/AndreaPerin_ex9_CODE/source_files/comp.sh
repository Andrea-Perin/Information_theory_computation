gfortran debug_module.f90 utils.f90 ex9.f90 -llapack -Ofast -g -Ofast -o ex9.x

