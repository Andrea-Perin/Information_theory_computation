gfortran debug_module.f90 utils.f90 state_comp.f90 -llapack -Ofast -g -Ofast -o state_comp.x

