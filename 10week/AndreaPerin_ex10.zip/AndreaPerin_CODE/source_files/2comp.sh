gfortran debug_module.f90 utils.f90 ex10_DMRG.f90 -L/usr/local/lib -llapack -lblas -g -o ex10_DMRG.x

