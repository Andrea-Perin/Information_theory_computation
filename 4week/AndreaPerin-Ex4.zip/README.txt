In both AndreaPerin-ex1/AndreaPerin-ex2, all results can be repeated by simply running the python scripts. All results (both text files and plots) are, however, already present. 
