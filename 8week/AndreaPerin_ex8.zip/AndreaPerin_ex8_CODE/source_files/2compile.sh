gfortran debug_module.f90 utils.f90 ex8_2.f90 -llapack -fcheck=all -g -Ofast -o part2.x
