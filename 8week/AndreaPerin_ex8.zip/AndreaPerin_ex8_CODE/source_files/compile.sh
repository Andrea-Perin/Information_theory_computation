gfortran debug_module.f90 utils.f90 ex8_1.f90 -llapack -Ofast -g -Ofast -o part1.x
