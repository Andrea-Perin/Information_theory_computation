Launch 'run_all.py' on python3 in order to compile, execute and plot all results.
