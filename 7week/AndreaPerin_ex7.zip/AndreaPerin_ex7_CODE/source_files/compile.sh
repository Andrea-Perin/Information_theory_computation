gfortran FFTW.f90 schrod.f90 debug_module.f90 lattice1d.f90 time_evo.f90 -llapack -lfftw3 -lm -o try.x
